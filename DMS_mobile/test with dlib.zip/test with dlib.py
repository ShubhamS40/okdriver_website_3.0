import cv2
import numpy as np
import dlib
import pygame
from scipy.spatial import distance
from imutils.video import VideoStream
import time

# === Load TFLite model if available ===
try:
    from tflite_runtime.interpreter import Interpreter
    tflite_available = True
    interpreter = Interpreter(model_path="final_drowsiness_model.tflite")
    interpreter.allocate_tensors()
    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()
except Exception as e:
    print("⚠️ TFLite model could not be loaded:", e)
    tflite_available = False

# === Setup Dlib ===
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")

# === Sound setup ===
pygame.mixer.init()
alarm_sound = "alarm.wav"

# === EAR / MAR config ===
EAR_THRESHOLD = 0.25
MAR_THRESHOLD = 0.5
drowsy_frames = 0
yawning_frames = 0
LEFT_EYE = list(range(36, 42))
RIGHT_EYE = list(range(42, 48))
MOUTH = list(range(60, 68))

def eye_aspect_ratio(eye):
    A = distance.euclidean(eye[1], eye[5])
    B = distance.euclidean(eye[2], eye[4])
    C = distance.euclidean(eye[0], eye[3])
    return (A + B) / (2.0 * C)

def mouth_aspect_ratio(mouth):
    A = distance.euclidean(mouth[2], mouth[6])
    B = distance.euclidean(mouth[3], mouth[5])
    C = distance.euclidean(mouth[0], mouth[4])
    return (A + B) / (2.0 * C)

# === Start Pi camera via imutils ===
vs = VideoStream(usePiCamera=True).start()
time.sleep(2.0)

print("📷 Drowsiness detection running. Press 'q' to quit.")

while True:
    frame = vs.read()
    if frame is None:
        print("⚠️ Frame not captured")
        continue

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = detector(gray)

    for face in faces:
        x, y, w, h = face.left(), face.top(), face.width(), face.height()
        x, y = max(0, x), max(0, y)
        face_img = gray[y:y+h, x:x+w]
        landmarks = predictor(gray, face)

        left_eye = [(landmarks.part(n).x, landmarks.part(n).y) for n in LEFT_EYE]
        right_eye = [(landmarks.part(n).x, landmarks.part(n).y) for n in RIGHT_EYE]
        mouth = [(landmarks.part(n).x, landmarks.part(n).y) for n in MOUTH]

        avg_EAR = (eye_aspect_ratio(left_eye) + eye_aspect_ratio(right_eye)) / 2.0
        mar = mouth_aspect_ratio(mouth)

        # CNN prediction
        cnn_label, cnn_conf = 0, 1.0
        if tflite_available:
            try:
                resized = cv2.resize(face_img, (64, 64)) / 255.0
                cnn_input = resized.astype(np.float32).reshape(1, 64, 64, 1)
                interpreter.set_tensor(input_details[0]['index'], cnn_input)
                interpreter.invoke()
                output_data = interpreter.get_tensor(output_details[0]['index'])
                cnn_label = int(np.argmax(output_data))
                cnn_conf = float(np.max(output_data))
            except Exception as e:
                print("⚠️ CNN inference failed:", e)

        final_label = "DROWSY" if cnn_label == 1 or avg_EAR < EAR_THRESHOLD else "ALERT"
        color = (0, 0, 255) if final_label == "DROWSY" else (0, 255, 0)

        # Draw results
        cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
        cv2.putText(frame, f"{final_label} (CNN: {cnn_conf:.2f})", (x, y - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
        cv2.putText(frame, f"EAR: {avg_EAR:.2f}  MAR: {mar:.2f}", (x, y + h + 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

        # Alarm logic
        if final_label == "DROWSY":
            drowsy_frames += 1
        else:
            drowsy_frames = 0

        if mar > MAR_THRESHOLD:
            yawning_frames += 1
        else:
            yawning_frames = 0

        if drowsy_frames >= 3 or yawning_frames >= 2:
            pygame.mixer.music.load(alarm_sound)
            pygame.mixer.music.play()
        else:
            pygame.mixer.music.stop()

    cv2.imshow("Drowsiness Detection - PiCam", frame)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cv2.destroyAllWindows()
pygame.mixer.quit()
vs.stop()
